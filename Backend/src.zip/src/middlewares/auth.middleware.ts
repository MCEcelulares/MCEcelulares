import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { HttpError } from "../types/http_error";

interface TokenPayload {
  id_usuario: number;
  permissoes: string[];
}

interface AuthenticatedRequest extends Request {
  userId?: number;
  permissoes?: string[];
}

function authMiddleware(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
) {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return next(new HttpError(401, "Token não informado"));
  }

  const [, token] = authHeader.split(" ");

  try {
    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET as string
    ) as TokenPayload;

    req.userId = decoded.id_usuario;
    req.permissoes = decoded.permissoes ?? [];

    return next();
  } catch (error) {
    return next(new HttpError(401, "Token inválido"));
  }
}

export default authMiddleware;